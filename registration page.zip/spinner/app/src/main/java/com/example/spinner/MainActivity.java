//package com.example.spinner;
//import androidx.annotation.RequiresApi;
//import androidx.appcompat.app.AppCompatActivity;
//import android.os.Build;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.TextView;
//import android.widget.Toast;
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.FileReader;
//import java.io.IOException;
//
//public class MainActivity extends AppCompatActivity {
//    private Button desiredText, measuredText, generateText;
//    private EditText inputText;
//    private TextView textView1, textView2, textView3;
//    private String desiredsignal = "desiredsignal.txt";
//    private String measuredsignal = "measuredsignal.txt";
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        desiredText = findViewById(R.id.button1);
//        measuredText = findViewById(R.id.button2);
//        generateText = findViewById(R.id.button3);
//        inputText = findViewById(R.id.editText1);
//        textView1 = findViewById(R.id.textView1);
//        textView2 = findViewById(R.id.textView2);
//        textView3 = findViewById(R.id.textView3);
//
//
//        desiredText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String input = inputText.getText().toString() + "\n";
//                try {
//                    FileOutputStream fOut = openFileOutput(desiredsignal, MODE_APPEND);
//                    fOut.write(input.getBytes());
//                    fOut.close();
//                    File fileDir = new File(getFilesDir(), desiredsignal);
//                    Toast.makeText(getBaseContext(), "File Saved at " + fileDir, Toast.LENGTH_LONG).show();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//        measuredText.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String input = inputText.getText().toString() + "\n";
//                try {
//                    FileOutputStream fOut = openFileOutput(measuredsignal, MODE_APPEND);
//                    fOut.write(input.getBytes());
//                    fOut.close();
//                    File fileDir = new File(getFilesDir(), measuredsignal);
//                    Toast.makeText(getBaseContext(), "File Saved at " + fileDir, Toast.LENGTH_LONG).show();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//
//        generateText.setOnClickListener(new View.OnClickListener() {
//            @RequiresApi(api = Build.VERSION_CODES.O)
//            @Override
//            public void onClick(View v) {
//                StringBuilder desired = read(getFilesDir() + "/" + desiredsignal);
//                StringBuilder measured = read(getFilesDir() + "/" + measuredsignal);
//                String[] diff = new String[desired.toString().split("\n").length];
//                String[] desired_list = desired.toString().split("\n");
//                String[] measured_list = measured.toString().split("\n");
//                for (int i = 0; i < desired_list.length; i++) diff[i] = String.valueOf(Math.abs(Float.parseFloat(desired_list[i]) - Float.parseFloat(measured_list[i])));
//
//                textView1.setText(desired.toString());
//                textView2.setText(measured.toString());
//                textView3.setText(String.join("\n", diff));
//
//            }
//        });
//
//    }
//    StringBuilder read(String path) {
//        StringBuilder text = new StringBuilder();
//        try {
//            BufferedReader br = new BufferedReader(new FileReader(path));
//            String line;
//
//            while ((line = br.readLine()) != null) {
//                text.append(line);
//                text.append('\n');
//            }
//            br.close();
//        }
//        catch (IOException e) {
//        }
//        return text;
//    }
//}


package com.example.spinner;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> countries = new ArrayList<String>();
    ArrayList<String> countries_ISO = new ArrayList<String>();
    ArrayList<String> cities = new ArrayList<String>();
    ArrayList<String> cities_pk = new ArrayList<String>();
    String countryISO = "";
    Spinner countries_spinner;
    Spinner cities_spinner;
    ArrayAdapter ad;
    int location_pk;
    String searchRes = "Not found";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        getCountryData();
//        getProfileData();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        class TreeNode {
            int value;
            TreeNode parent;
            TreeNode child1;
            TreeNode child2;
            public TreeNode(int value) {
                this.value = value;
            }
            public void setLeft(int value) {
                child1 = new TreeNode(value);
                child1.parent = this;
            }
            public void setRight(int value) {
                child2 = new TreeNode(value);
                child2.parent = this;
            }
            public boolean search(int value) {
                boolean found = false;
                if (value == this.value) {
                    searchRes = String.format("Value: %d%nParent value: %s%nChild1 value: %d%nChild2 value: %d", value, (parent == null ? "is root node" : String.valueOf(parent.value)), (child1 == null ? null : child1.value), (child2 == null ? null : child2.value));
                    return true;
                }
                searchRes = "Not found";
                return ((child1 != null && child1.search(value)) || (child2 != null && child2.search(value)));
            }
        }
        final TreeNode node = new TreeNode(0);
        node.setLeft(1);
        node.setRight(2);
        node.child1.setLeft(3);
        node.child1.setRight(4);

        final TextView res = findViewById(R.id.textView3);
        final EditText input = findViewById(R.id.editTextNumber);
        Button search = findViewById(R.id.button4);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(input.getText().toString())) res.setText("Please enter node");
                else {
                    node.search(Integer.parseInt(input.getText().toString()));
                    res.setText(searchRes);

                }
            }
        });

    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(), Login.class));
        finish();
    }




//    void getCountryData() {
//        final String[][] res = new String[2][];
//        String url = "http://104.248.51.94:8000/api/v1/location/countries/";
//        RequestQueue queue = Volley.newRequestQueue(this);
//        JsonArrayRequest getRequest = new JsonArrayRequest(com.android.volley.Request.Method.GET, url,null,
//                new Response.Listener<JSONArray>()
//                {
//                    @Override
//                    public void onResponse(JSONArray response) {
//                        for (int i = 0; i < response.length(); i++) {
//                            try {
//                                countries.add((String) response.getJSONObject(i).get("country_name"));
//                                countries_ISO.add((String) response.getJSONObject(i).get("country_ISO"));
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        countries_spinner = (Spinner) findViewById(R.id.coursesspinner);
//                        ad = new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_item, countries);
//                        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                        countries_spinner.setAdapter(ad);
//                        countries_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//                            @Override
//                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                                cities.clear();
//                                countryISO = countries_ISO.get(countries.indexOf(parent.getItemAtPosition(position).toString()));
//                                Toast.makeText(MainActivity.this, countries_spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
//                                getCityData();
//                            }
//                            @Override
//                            public void onNothingSelected(AdapterView<?> parent) {
//                            }
//                        });
//                    }
//                },
//                new Response.ErrorListener()
//                {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.d("Error.Response", error.toString());
//                    }
//                }
//        );
//        queue.add(getRequest);
//    }
//    void getCityData() {
//        final String[][] res = new String[2][];
//        String url = "http://104.248.51.94:8000/api/v1/location/city/?country=" + countryISO;
//        System.out.println(url);
//        RequestQueue queue = Volley.newRequestQueue(this);
//        JsonArrayRequest getRequest = new JsonArrayRequest(com.android.volley.Request.Method.GET, url,null,
//                new Response.Listener<JSONArray>()
//                {
//                    @Override
//                    public void onResponse(JSONArray response) {
//                        for (int i = 0; i < response.length(); i++) {
//                            try {
//                                cities.add((String) response.getJSONObject(i).get("city_name"));
//                                cities_pk.add( response.getJSONObject(i).get("pk").toString());
//                            } catch (JSONException e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        cities_spinner = (Spinner) findViewById(R.id.coursesspinner1);
//                        ad = new ArrayAdapter(MainActivity.this, android.R.layout.simple_spinner_item, cities);
//                        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//                        cities_spinner.setAdapter(ad);
//                        cities_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//                            @Override
//                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                                location_pk = Integer.parseInt(cities_pk.get(cities.indexOf(parent.getItemAtPosition(position).toString())));
//                                Toast.makeText(MainActivity.this, cities_spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
//                            }
//                            @Override
//                            public void onNothingSelected(AdapterView<?> parent) {
//                            }
//                        });
//                    }
//                },
//                new Response.ErrorListener()
//                {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Log.d("Error.Response", error.toString());
//                    }
//                }
//        );
//        queue.add(getRequest);
//    }
//    void getProfileData () {
//        String url = "http://104.248.51.94:8000/api/v1/account/profile/";
//        RequestQueue queue = Volley.newRequestQueue(this);
//        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET, url, null,
//                new Response.Listener() {
//                    @Override
//                    public void onResponse(Object response) {
//                        System.out.println(response.toString());
//                        System.out.println("asdfasdf");
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                    }
//                })
//        {
//            @Override
//            public Map getHeaders() throws AuthFailureError {
//                HashMap headers = new HashMap();
//                headers.put("Authorization", "Token f01e104066e995a47e4e98d255f046939d8a22a8");
//                return headers;
//            }
//        };
//        queue.add(jsonObjReq);
//    }
}

