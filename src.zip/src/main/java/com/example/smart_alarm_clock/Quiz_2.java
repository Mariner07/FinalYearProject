package com.example.smart_alarm_clock;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Quiz_2 extends AppCompatActivity {

    Map<String, String> questions = new HashMap<String, String>();
    int questionNo = 1;
    int NoOfQuestions = 5;
    TextView question, answer1, answer2, answer3, outcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_2);
        answer1 = findViewById(R.id.Answer1);
        answer2 = findViewById(R.id.Answer2);
        answer3 = findViewById(R.id.Answer3);
        question = findViewById(R.id.Question);
        outcome = findViewById(R.id.Outcome);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference q1 = database.getReference("Question1");

        q1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String value = dataSnapshot.getValue(String.class);
                String[] question = value.split("\\|");

                questions.put("Question1", question[0]);
                questions.put("Right1", question[1]);
                questions.put("WrongA1", question[2]);
                questions.put("WrongB1", question[3]);

            }

            @Override
            public void onCancelled(DatabaseError error) {
                Toast.makeText(Quiz_2.this, error.toString(),Toast.LENGTH_SHORT).show();
            }
        });

        DatabaseReference q2 = database.getReference("Question2");
        q2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);

                String[] q2 = value.split("\\|");
                questions.put("Question2", q2[0]);
                questions.put("Right2", q2[1]);
                questions.put("WrongA2", q2[2]);
                questions.put("WrongB2", q2[3]);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Quiz_2.this, error.toString(),Toast.LENGTH_SHORT).show();
            }

        });

        DatabaseReference q3 = database.getReference("Question3");
        q3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);

                String[] q3 = value.split("\\|");
                questions.put("Question3", q3[0]);
                questions.put("Right3", q3[1]);
                questions.put("WrongA3", q3[2]);
                questions.put("WrongB3", q3[3]);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Quiz_2.this, error.toString(),Toast.LENGTH_SHORT).show();
            }
        });
        DatabaseReference q4 = database.getReference("Question4");
        q4.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);

                String[] q4 = value.split("\\|");
                questions.put("Question4", q4[0]);
                questions.put("Right4", q4[1]);
                questions.put("WrongA4", q4[2]);
                questions.put("WrongB4", q4[3]);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Quiz_2.this, error.toString(),Toast.LENGTH_SHORT).show();
            }
        });

        DatabaseReference q5 = database.getReference("Question5");
        q5.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String value = dataSnapshot.getValue(String.class);

                String[] q5 = value.split("\\|");
                questions.put("Question5", q5[0]);
                questions.put("Right5", q5[1]);
                questions.put("WrongA5", q5[2]);
                questions.put("WrongB5", q5[3]);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Quiz_2.this, error.toString(),Toast.LENGTH_SHORT).show();
            }
        });


        question.setTextColor(Color.MAGENTA);
        answer1.setTextColor(Color.GRAY);
        answer2.setTextColor(Color.GRAY);
        answer3.setTextColor(Color.GRAY);

        setQuestion();

    }

    void setQuestion(){
        question.setText(questions.get("Question"+questionNo));
        Random r = new Random();

        int RandmIntValue = r.nextInt(3);
        if (RandmIntValue==0){
            answer1.setText(questions.get("Right"+questionNo));
            answer1.setTag("Correct");
            answer2.setTag("Wrong");
            answer3.setTag("Wrong");
            answer2.setText(questions.get("WrongA"+questionNo));
            answer3.setText(questions.get("WrongB"+questionNo));
        }
        if (RandmIntValue==1){
            answer2.setText(questions.get("Right"+questionNo));
            answer2.setTag("Correct");
            answer1.setTag("Wrong");
            answer3.setTag("Wrong");
            answer1.setText(questions.get("WrongA"+questionNo));
            answer3.setText(questions.get("WrongB"+questionNo));
        }
        if (RandmIntValue==2){
            answer3.setText(questions.get("Right"+questionNo));
            answer3.setTag("Correct");
            answer2.setTag("Wrong");
            answer1.setTag("Wrong");
            answer1.setText(questions.get("WrongA"+questionNo));
            answer2.setText(questions.get("WrongB"+questionNo));
        }
    }

    public void onAnswerClick(View v){
        if (v.getTag()=="Correct"){
            questionNo++;
            if (questionNo>NoOfQuestions){
                outcome.setTextColor(Color.GREEN);
                outcome.setText("You successfully finished the quiz\nClick me to exit");
                question.setVisibility(View.INVISIBLE);
                answer1.setVisibility(View.INVISIBLE);
                answer2.setVisibility(View.INVISIBLE);
                answer3.setVisibility(View.INVISIBLE);

            }else {
                outcome.setTextColor(Color.GREEN);
                outcome.setText("Well done");
                setQuestion();
            }
        }else {
            outcome.setTextColor(Color.RED);
            outcome.setText("You can play again");
        }
    }

    public void onClickFinish(View v){
        if (outcome.getText().toString().contains("successfully")==true){
            onDestroy();
            finish();
            moveTaskToBack(true);
            System.exit(0);
        }
    }
}