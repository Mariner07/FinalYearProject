package com.example.smart_alarm_clock;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    TextClock currentTime;
    TextView alarmSetView;
    Button setAlarmbtn;
    TextView quiz1;
    TextView quiz2;

    boolean status=false;
    int Amin = 0, Ahour = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setAlarmbtn = findViewById(R.id.setAlarmbtn);
        currentTime = findViewById(R.id.textClock);
        alarmSetView = findViewById(R.id.AlarmSetView);
        quiz1 = findViewById(R.id.Game1);
        quiz2 = findViewById(R.id.Game2);

        alarmSetView.setText("Alarm set: ".concat(AlarmTime()));
        final Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));


        setAlarmbtn.setOnClickListener(view -> {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int Hour, int Minute) {
                    Ahour= Hour;
                    Amin = Minute;

                    alarmSetView.setText("Alarm set: ".concat(AlarmTime()));
                }
            }, Ahour, Amin,false);
            timePickerDialog.show();
                }
        );


        Timer t = new Timer();
        t.scheduleAtFixedRate(new TimerTask() {
            @RequiresApi(api = Build.VERSION_CODES.P)
            @Override
            public void run() {



                if (currentTime.getText().toString().equals(AlarmTime())){
                    status = true;
                }

                if(status){
                    r.play();
                }
                else{
                    r.stop();
                }


            }
        }, 0, 1000);



        quiz1.setOnClickListener(view -> {
            Game1();
        });
        quiz2.setOnClickListener(view -> {
            Game2();
        });

    }

    void Game1(){
        Intent intent = new Intent(this, Quiz_body.class);
        startActivity(intent);
    }
    void Game2(){
        Intent intent2 = new Intent(this, Quiz_2.class);
        startActivity(intent2);
    }

    public String AlarmTime(){

        int alarmHours = Ahour;
        int alarmMinutes = Amin;
        String stringAlarmMinutes;

        if (alarmMinutes<10){
            stringAlarmMinutes = "0";
            stringAlarmMinutes = stringAlarmMinutes.concat(Integer.toString(alarmMinutes));
        }else{
            stringAlarmMinutes = Integer.toString(alarmMinutes);
        }
        String stringAlarmTime;

        if(alarmHours>12){
            alarmHours = alarmHours-12;
            stringAlarmTime = Integer.toString(alarmHours).concat(":").concat(stringAlarmMinutes).concat(" PM");
        }
        else if(alarmHours==12){
            stringAlarmTime = Integer.toString(alarmHours).concat(":").concat(stringAlarmMinutes).concat(" PM");
        }else{
            stringAlarmTime = Integer.toString(alarmHours).concat(":").concat(stringAlarmMinutes).concat(" AM");
        }
        return stringAlarmTime;
    }

}

